

<!---follow the includes position--->

<?php
	include'header.php';
	include'sidebar.php';
?>

	<!--sidenavigation-->

	<nav id="mySidenav" class="sidenav">
		<!-- you can change this depends on you--->
			  <button type="button" class="btn btn-danger mt-2 ml-2" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-user-cog"></i></button>
			  <button type="button" class="btn btn-danger mt-2"><i class="fas fa-plus"></i></button>
			  <button type="button" class="btn btn-danger mt-2"><i class="fas fa-question-circle"></i></button>
			  <button type="button" class="btn btn-danger mt-2"><i class="fas fa-sliders-h"></i></button>
	      <hr>

	      <!-- Change this depends on your module--->

	    <div class="sample nav flex-column nav-pills mt-3" id="v-pills-tab" role="tablist" aria-orientation="vertical">
	      <a class="bg-danger active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true"><i class="fas fa-home"></i> Home</a>
	      <a class="" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="false">Budget Allocation</a>
	      <a class="" id="v-pills-messages-tab" data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">Budget Request</a>
	      <a class="k" id="v-pills-settings-tab" data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false">Budget Report</a>
	    </div>
	</nav>


	<!--head navigation--->

	<div id="main">
	  <ul class="barbutton nav sticky-top">
	  	 <!--<h3 class="text-white"><img src="images/samplelogo2.png" class="card-img-top" alt="..."></h3>-->
	  	 <h3 class="text-white ml-3 p-2">Skyline Hotel and Restaurant</h3>
  		<ul class="navbar-nav mr-auto">
	    </ul>
	  
	    <span class="navbar-text mr-2">
			<div class="btn-group mr-md-2">
			  <button class="settings btn btn-outline-danger btn-sm border-0 text-white rounded-pill" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-toggle="tooltip" data-placement="top" title="Account Settings"><img class="avatar rounded-circle" src="images/sampleimg.jpeg" width="30" height="30"><i class="welcome"> Welcome! Administrator </i><div class="spinner-grow spinner-grow-sm text-success" role="status">
					  <span class="sr-only"></span>
					</div></button>
			  <div class="dropdown-menu dropdown-menu-right">
			    <a class="dropdown-item text-secondary" href="#"><i class="fas fa-sign-out-alt"></i> Logout</a>
			  </div>
			</div>
	    </span>
	  </ul>

	  <!-- insert your transaction here--->
	  
    <div class="container-fluid">
    	<div class="tab-content" id="v-pills-tabContent">
	      <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
	      	<!---First transaction here-->
	      </div>
	      <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
	      	<h1>Budget Allocation</h1>
	      	<!---Second transaction here-->
	      </div>
	      <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
	      	<h1>Budget Request</h1>
	      	<!---third transaction here-->
	      </div>
	      <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
	      	<h1>Budget Report</h1>
	      	<!---fourth transaction here-->
	      </div>
	    </div>
    </div>

