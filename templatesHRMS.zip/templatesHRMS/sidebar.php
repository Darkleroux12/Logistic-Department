 

 <!--sidebar navigation-->
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.css">

 <nav class="sidebar">
	  <a href="#about" data-toggle="tooltip" data-placement="top" title="Menu"><span class="buttonOpenCLosetext-white" style="font-size:20px;cursor:pointer" onclick="openNav()">&#9776;</span></a>
	  <a href="index.php" class="bg-danger active" data-toggle="tooltip" data-placement="top" title="Dashboard"><i class="fas fa-chart-line"></i></a>
	  <a href="transaction1.php" data-toggle="tooltip" data-placement="top" title="Vendor Portal & Procurement"><i class="fas fa-blog"></i></a>
	  <a href="transaction2.php" data-toggle="tooltip" data-placement="top" title="Fleet & Vehicle Management"><i class="fas fa-truck"></i></a>
	  <a href="transaction3.php" data-toggle="tooltip" data-placement="top" title="Maintenance Repair And Overhaul"><i class="fas fa-tools"></i></a>
	  <a href="transaction4.php" data-toggle="tooltip" data-placement="top" title="Asset Management"><i class="fas fa-coins"></i></a>
	  <a href="transaction5.php" data-toggle="tooltip" data-placement="top" title="Audit & Warehouse"><i class="fas fa-warehouse"></i></a>
	  <a href="transaction6.php" data-toggle="tooltip" data-placement="top" title="Front Office"><i class="fas fa-phone"></i></a>
	  <a href="transaction7.php" data-toggle="tooltip" data-placement="top" title="Room Facility Management"><i class="fas fa-key"></i></a>
	  <a href="transaction8.php" data-toggle="tooltip" data-placement="top" title="Housekeeping & Laundry Management"><i class="fas fa-broom"></i></a>
	  <a href="transaction9.php" data-toggle="tooltip" data-placement="top" title="Billing"><i class="fas fa-money-check"></i></a>
	  <a href="transaction10.php" data-toggle="tooltip" data-placement="top" title="Supply Management"><i class="fas fa-truck-loading"></i></a>
	  <a href="transaction11.php" data-toggle="tooltip" data-placement="top" title="Financial Report"><i class="fas fa-receipt"></i></a>
	  <a href="transaction12.php" data-toggle="tooltip" data-placement="top" title="Audit Trail"><i class="fas fa-clipboard-check"></i></a>
</nav>

<script>
		var toggleStatus = 1;
		function openNav(){
			if (toggleStatus == 1) {
				document.getElementById("mySidenav").style.width = "0";
				document.getElementById("main").style.marginLeft = "50px";
				toggleStatus = 0;
			}else if(toggleStatus == 0){
				document.getElementById("mySidenav").style.width = "200px";
				document.getElementById("main").style.marginLeft = "250px";
				toggleStatus = 1;
			}
		}
 </script>