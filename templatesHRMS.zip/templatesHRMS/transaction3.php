
<!---follow the includes position--->

<?php
	include'header.php';
	include'sidebar.php';
?>

	<!--sidenavigation-->

	<nav id="mySidenav" class="sidenav">
		<!-- you can change this depends on you--->
			  <button type="button" class="btn btn-danger mt-2 ml-2" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-user-cog"></i></button>
			  <button type="button" class="btn btn-danger mt-2"><i class="fas fa-plus"></i></button>
			  <button type="button" class="btn btn-danger mt-2"><i class="fas fa-question-circle"></i></button>
			  <button type="button" class="btn btn-danger mt-2"><i class="fas fa-sliders-h"></i></button>
	      <hr>

	      <!-- Change this depends on your module--->

	    <div class="sample nav flex-column nav-pills mt-3" id="v-pills-tab" role="tablist" aria-orientation="vertical">
	      <a class="bg-danger active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="true"><i class="fas fa-home"></i> Home</a>

	      <a class="" id="v-pills-work-tab" data-toggle="pill" href="#v-pills-work" role="tab" aria-controls="v-pills-work" aria-selected="false">Work Orders</a>

	      <a class="" id="v-pills-request-tab" data-toggle="pill" href="#v-pills-request" role="tab" aria-controls="v-pills-request" aria-selected="false">View Request</a>

	      <a class="k" id="v-pills-personnel-tab" data-toggle="pill" href="#v-pills-personnel" role="tab" aria-controls="v-pills-personnel" aria-selected="false">My Personnel</a>

	      <a class="k" id="v-pills-maintenance-tab" data-toggle="pill" href="#v-pills-maintenance" role="tab" aria-controls="v-pills-maintenance" aria-selected="false">Maintenance Schedule</a>

	      <a class="k" id="v-pills-overhaul-tab" data-toggle="pill" href="#v-pills-overhaul" role="tab" aria-controls="v-pills-overhaul" aria-selected="false">Overhaul</a>

	      <a class="k" id="v-pills-supplies-tab" data-toggle="pill" href="#v-pills-supplies" role="tab" aria-controls="v-pills-supplies" aria-selected="false">View Supplies</a>

	      <a class="k" id="v-pills-reports-tab" data-toggle="pill" href="#v-pills-reports" role="tab" aria-controls="v-pills-reports" aria-selected="false">Reports</a>
	    </div>
	</nav>


	<!--head navigation--->

	<div id="main">
	  <ul class="barbutton nav sticky-top">
	  	 <!--<h3 class="text-white"><img src="images/samplelogo2.png" class="card-img-top" alt="..."></h3>-->
	  	 <h3 class="text-white ml-3 p-2">Skyline Hotel and Restaurant</h3>
  		<ul class="navbar-nav mr-auto">
	    </ul>
	  
	    <span class="navbar-text mr-2">
			<div class="btn-group mr-md-2">
			  <button class="settings btn btn-outline-danger btn-sm border-0 text-white rounded-pill" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-toggle="tooltip" data-placement="top" title="Account Settings"><img class="avatar rounded-circle" src="images/sampleimg.jpeg" width="30" height="30"><i class="welcome"> Welcome! Administrator </i><div class="spinner-grow spinner-grow-sm text-success" role="status">
					  <span class="sr-only"></span>
					</div></button>
			  <div class="dropdown-menu dropdown-menu-right">
			    <a class="dropdown-item text-secondary" href="#"><i class="fas fa-sign-out-alt"></i> Logout</a>
			  </div>
			</div>
	    </span>
	  </ul>

	  <!-- insert your transaction here--->
	  
    <div class="container-fluid">
    	<div class="tab-content" id="v-pills-tabContent">
	      <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
	      	<!---First transaction here-->
	      	Dashboard ng sub module nyo
	      </div>














	      <div class="tab-pane fade" id="v-pills-work" role="tabpanel" aria-labelledby="v-pills-work-tab">
	      	<h1>Work Orders</h1>
	      	<!---Second transaction here-->
	      	









	      </div>
	      <div class="tab-pane fade" id="v-pills-request" role="tabpanel" aria-labelledby="v-pills-request-tab">
	      	<h1>View Request</h1>
	      	<!---third transaction here-->
	      	
	      </div>
















	      <div class="tab-pane fade" id="v-pills-personnel" role="tabpanel" aria-labelledby="v-pills-personnel-tab">
	      	<h1>My Personnel</h1>
	      	<!---fourth transaction here-->
	      
	      </div>











	      <div class="tab-pane fade" id="v-pills-maintenance" role="tabpanel" aria-labelledby="v-pills-maintenance-tab">
	      	<h1>Maintenance Schedule</h1>
	      	<!---fifth transaction here-->
	   
	      </div>








	      <div class="tab-pane fade" id="v-pills-overhaul" role="tabpanel" aria-labelledby="v-pills-overhaul-tab">
	      	<h1>Overhaul</h1>
	      	<!---sixth transaction here-->
	      	
	      </div>









	      <div class="tab-pane fade" id="v-pills-supplies" role="tabpanel" aria-labelledby="v-pills-supplies-tab">
	      	<h1>View Supplies</h1>
	      	<!---seventh transaction here-->
	      
	      </div>
















	      <div class="tab-pane fade" id="v-pills-reports" role="tabpanel" aria-labelledby="v-pills-reports-tab">
	      	<h1>Reports</h1>
	      	<!---eighth transaction here-->
	      	
	      </div>
	    </div>
    </div>

